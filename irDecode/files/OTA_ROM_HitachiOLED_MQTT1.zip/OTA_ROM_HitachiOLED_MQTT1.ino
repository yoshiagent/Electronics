#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <PubSubClient.h>
#include "mqtt_secrets.h"
#include "HTML.h"
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>
#include <ESP8266HTTPUpdateServer.h>
#include <EEPROM.h>
#include <IRsend.h>
#include <U8g2lib.h>
#include <Wire.h>
#include <ir_Hitachi.h>
#include "DHTesp.h"
#define led 2
uint16_t mqttPort=1883;
const char* s_topic="channels/1882331/subscribe/fields/field3";
const char* s_topic4="channels/1882331/subscribe/fields/field4";
const char* s_topic5="channels/1882331/subscribe/fields/field5";
const char* mqtt_server = "mqtt3.thingspeak.com";
U8G2_SSD1306_128X64_NONAME_F_HW_I2C  u8g2(U8G2_R0, U8X8_PIN_NONE);
IRHitachiAc344 _ac(D8); 
unsigned int flag;
int tempNow;
int fanNow;
DHTesp dht;
float t=0;
float h=0;
uint8_t getT;
uint8_t getF;
uint8_t getM;
uint8_t ifAP=1;
String sM;
String sF;
static String acState;
uint8_t draw_state = 0;
const char* host = "mydns";//mDNS使用
String sssid = "";
String spass = "";
String Essid = "";                 //EEPROM Network SSID
String Epass = "";
String sEssid = "";                 //EEPROM Network SSID
String sEpass = "";
int tempThreshhold=28;
ESP8266WebServer server(80);
ESP8266HTTPUpdateServer httpUpdater;
WiFiClient  espclient;
PubSubClient client(espclient);

void f_newNet() {
  server.send(200, "text/html", sNewNet);
}
       
void ap(){
  for (int i = 0; i < 64; ++i) { EEPROM.write(i, 0); }
  EEPROM.commit();
  WiFi.softAP("espAP");
  Serial.println("in AP mode");
  }
void st(){
  readSSID();
  if ( Essid.length() > 1 ) {
    WiFi.begin(Essid, Epass);
    while (WiFi.status() != WL_CONNECTED) { delay(500); }
    WiFi.softAP(String("IPGGx-"+String((WiFi.localIP().toString()))),"");
     }
  client.setServer(mqtt_server, mqttPort);
  client.setCallback(callback);  
  }
void readSSID(){
   for (int i = 0; i < 32; ++i)    
    {      Essid += char(EEPROM.read(i));    }
  for (int i = 32; i < 64; ++i)   //Reading Password
    {      Epass += char(EEPROM.read(i));    }
 }



void f_regSSID() {
  if (server.hasArg("SSID") && server.hasArg("PASSWORD")){
   sssid=server.arg("SSID");//Get SSID
   spass=server.arg("PASSWORD");//Get Password
  }
    
     for (int i = 0; i < sssid.length(); ++i)
          {EEPROM.write(i, sssid[i]);}
     for (int i = 0; i < spass.length(); ++i)
          {EEPROM.write(32+i, spass[i]);}
     EEPROM.commit();
    
     for (int i = 0; i < 32; ++i)     //Reading SSID
           {
             sEssid += char(EEPROM.read(i));
           }
          for (int i = 32; i < 64; ++i)   //Reading Password
           {
             sEpass += char(EEPROM.read(i));
           }
          
    String sSSID="<p>SSID:"+sEssid+"</p>";
    String sPASS="<p>Pass:"+sEpass+"</p>";
    server.send(200,"text/html",sFinishedhead+sSSID+sPASS+sFinishedend);
      ifAP=0;
      }
   /*
     此處放你的程式碼
  */
  void handleLedControl() {
    server.send(200, "text/html", html_LedCon);
 }
void accRon(){
_ac.on();//生成空調“開”的紅外碼
  _ac.setMode(3);//1:送風 3:冷氣 5:除溼 6:暖氣
  _ac.setTemp(26);//16~32
  _ac.setFan(5);//1~6  1:靜 2:微 3:弱 4:強 5:AUTO 6:最大
  _ac.setSwingV(0);//0:off 1:on
  _ac.setSwingH(0); //0:Auto 1:RightMost 2:Right 3:Middle 4:Left 5:LeftMost
  //Serial.println(_ac.toString());//顯示發送的空調開機紅外編碼
  _ac.send();//發送紅外命令
  getT=_ac.getTemp();
  getF=_ac.getFan();
  getM=_ac.getMode();
  
  switch(getF) {
    case 1: sF="靜"; break;
    case 2: sF="微"; break;
    case 3: sF="弱"; break;
    case 4: sF="強"; break;
    case 5: sF="自動"; break;
    case 6: sF="超強"; break;
  }
 
  switch(getM) {
    case 1: sM="送風"; break;
    case 3: sM="冷氣"; break;
    case 5: sM="除濕"; break;
    case 6: sM="暖氣"; break;
  }
  acState=sM+" "+String(getT)+"C "+sF;
  
}
void accRoff(){
  _ac.off();
  _ac.send();//發送紅外命令
  acState="冷氣已關";
}
void AcON() {
  server.sendHeader("Location","/acc");
  server.send(303);
  _ac.on();//生成空調“開”的紅外碼
  _ac.setMode(3);//1:送風 3:冷氣 5:除溼 6:暖氣
  _ac.setTemp(26);//16~32
  _ac.setFan(5);//1~6  1:靜 2:微 3:弱 4:強 5:AUTO 6:最大
  _ac.setSwingV(0);//0:off 1:on
  _ac.setSwingH(0); //0:Auto 1:RightMost 2:Right 3:Middle 4:Left 5:LeftMost
  //Serial.println(_ac.toString());//顯示發送的空調開機紅外編碼
  _ac.send();//發送紅外命令
  getT=_ac.getTemp();
  getF=_ac.getFan();
  getM=_ac.getMode();
  
  switch(getF) {
    case 1: sF="靜"; break;
    case 2: sF="微"; break;
    case 3: sF="弱"; break;
    case 4: sF="強"; break;
    case 5: sF="自動"; break;
    case 6: sF="超強"; break;
  }
 
  switch(getM) {
    case 1: sM="送風"; break;
    case 3: sM="冷氣"; break;
    case 5: sM="除濕"; break;
    case 6: sM="暖氣"; break;
  }
  acState=sM+" "+String(getT)+"C "+sF;
 }
void AcOFF() {
  _ac.off();
  _ac.send();//發送紅外命令
  acState="冷氣已關";
  server.sendHeader("Location","/acc");
  server.send(303);
}
void f_tup() {
  server.sendHeader("Location","/acc");
  server.send(303);
  getT=_ac.getTemp();
  if(getT>=32) getT=31;
  _ac.setTemp(getT+1);//16~32
  _ac.send();//發送紅外命令
  getT=_ac.getTemp();
  acState=sM+" "+String(getT)+"C "+sF;
  
  
}

void f_tdn() {
  server.sendHeader("Location","/acc");
  server.send(303);
  getT=_ac.getTemp();
  if(getT<=16) getT=17;
  _ac.setTemp(getT-1);//16~32
  _ac.send();//發送紅外命令
  getT=_ac.getTemp();
  acState=sM+" "+String(getT)+"C "+sF;
}

void drawP1(){
    u8g2.setFont(u8g2_font_unifont_t_chinese1);
    u8g2.setCursor(0, 2);
    u8g2.print(String(acState).c_str());
    //u8g2.print(String(getT).c_str());
    //u8g2.setFont(u8g2_font_helvB12_tf);
    //u8g2.print("°");
    //u8g2.setFont(u8g2_font_unifont_t_chinese1);
    //u8g2.print("C");
    u8g2.setCursor(10, 25);
    u8g2.print(String("溫度:").c_str());
    u8g2.print(String(t).c_str());
 
    u8g2.setFont(u8g2_font_helvB12_tf);
    u8g2.print("°");
    u8g2.setFont(u8g2_font_unifont_t_chinese1);
    u8g2.print("C");
 
    u8g2.setCursor(10, 45);
    u8g2.print(String("濕度:").c_str());
    u8g2.print(String(h).c_str());
    u8g2.print('%');
   // u8g2.setCursor(0, 50);
   // u8g2.print(String("111.9.21聰耀敬贈").c_str());
  }
  void draw(void) {
   switch(draw_state) {
    case 0: drawP1(); break;
   // case 1: drawPicture(); break;
   // case 2: drawP2(); break;
  }
  }

void callback(char* topic, uint8_t* payload, unsigned int length) {
  delay(1000);
  Serial.println("");
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  String payloadTemp;
  for (int i = 0; i < length; i++) {
    payloadTemp += (char)payload[i];
    Serial.print((char)payload[i]);
    //Serial.println(length);
  }
   tempNow=payloadTemp.toInt();
   if(tempNow>=10 && tempNow<=16) {
   
   fanNow=tempNow-10;
   Serial.println("tempNow");
   Serial.println(tempNow);
   switch(fanNow) {
    case 1: {_ac.setFan(1);_ac.send();acState="靜"; break;}
    case 2: {_ac.setFan(2);_ac.send();sF="微"; break;}
    case 3: {_ac.setFan(3);_ac.send();sF="弱"; break;}
    case 4: {_ac.setFan(4);_ac.send();sF="強"; break;}
    case 5: {_ac.setFan(5);_ac.send();sF="自動"; break;}
    case 6: {_ac.setFan(6);_ac.send();sF="超強"; break;}
    
  }
  acState=sM+" "+String(getT)+"C "+sF;
   }

  if(tempNow>=17 && tempNow<=32) {
    _ac.setTemp(tempNow);//16~32
    _ac.send();//發送紅外命令
    getT=_ac.getTemp();
    acState=sM+" "+String(getT)+"C "+sF;
    }


  
   
   Serial.println("");
   Serial.print("tempNow=");
   Serial.print(tempNow);
  //if (tempNow>=tempThreshhold ) {
  if (tempNow==1 ) {
     accRon();
     digitalWrite(led, LOW);
     }
   else if(tempNow==0 )
    { accRoff();
      digitalWrite(led, HIGH);
    }
}
void reconnect() {
  while (!client.connected()) {
    Serial.println("Attempting MQTT connection...");
    if (client.connect(SECRET_MQTT_CLIENT_ID,SECRET_MQTT_USERNAME, SECRET_MQTT_PASSWORD)) {
      Serial.println("connected");
      client.subscribe(s_topic,0);
      client.subscribe(s_topic4,0);
      client.subscribe(s_topic5,0);
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      delay(5000);
    }
  }
}
void setup(){
 Serial.begin(115200);
 pinMode(led,OUTPUT);
 Serial.println("");
 pinMode(RX,OUTPUT);
 pinMode(TX,OUTPUT);
 digitalWrite(TX,1);//使用TX接腳當OLED VCC
 digitalWrite(RX,0);//使用RX接腳當OLED GND
 delay(2000); 
 u8g2.begin();
 u8g2.enableUTF8Print();
 u8g2.setFont(u8g2_font_6x10_tf);
 u8g2.setFontRefHeightExtendedText();
  u8g2.setDrawColor(1);
  u8g2.setFontPosTop();
  u8g2.setFontDirection(0);
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_unifont_t_chinese1);
   acState="冷氣控制";
   _ac.begin();
   dht.setup(D7, DHTesp::DHT11);
   delay(2000);
     
  EEPROM.begin(64);
  readSSID();
  WiFi.mode(WIFI_AP_STA);
  flag=0;
  while (WiFi.waitForConnectResult() != WL_CONNECTED) {
    WiFi.begin(Essid, Epass);
    delay(500);
    flag++;
    if (flag >=5) break;
  }
    if (flag>=4) ap();
    else {st(); ifAP=0;}
  server.on("/", f_newNet);
  server.on("/regSSID", f_regSSID);//form action
  server.on("/1", AcON);//與formaction 對應
  server.on("/0", AcOFF);
  server.on("/acc", handleLedControl);
  server.on("/tup", f_tup);//與formaction 對應
  server.on("/tdn", f_tdn);
  MDNS.begin(host);//啟動mdns服務
  httpUpdater.setup(&server); //配置webserver為更新server
  server.begin();
  MDNS.addService("http", "tcp", 80);
    
}

void loop(void) {
  delay(dht.getMinimumSamplingPeriod());
  t = dht.getTemperature();
  h = dht.getHumidity();
  u8g2.firstPage();
  do { 
      draw();
     } while (u8g2.nextPage());
  draw_state++;
  if ( draw_state >0 ){
    draw_state = 0;
 delay(500);
  }
 if(ifAP==0){
  if (!client.connected()) {
    reconnect();
  }
  client.loop();}
  server.handleClient();
  MDNS.update();
}
