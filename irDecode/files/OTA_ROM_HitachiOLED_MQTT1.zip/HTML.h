String sNewNet = R"=====(
<!DOCTYPE html>
<html>
    <head>
      <meta charset="UTF-8" />
      <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
      <title>設定ROUTER連線</title>
      <style>
      body {text-align: center;}
      input[type=submit] {background-color: #50FF50;font-size: 24px;}
      input[type=text]{font-size: 24px;max-width: 200px;}
      p {font-size: 22px;}
 </style>
    </head>
<body >
<h1>
網路設定
</h1>
<h1>
 <form action="/regSSID">
  <input type="text" placeholder="請輸入SSID" name="SSID" value="" size="8">
  <p>
  <input type="text" placeholder="請輸入PASSWORD" name="PASSWORD" value="" size="20">
  </p>
  <p>
  <input type="submit" value="Submit">
  </p>
</form>
</h1>
</body>
</html>
)=====";
String html_LedCon = R"=====(
<!DOCTYPE html>
<html>
    <head>
      <meta charset="UTF-8" />
      <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
      <title>Hitachi 空調控制</title>
     <style>
        body { background-color: linen;}
       input{
          font-size:24px;
          width:100px;
          height:50px;
         margin-top: 10px;
         margin-bottom: 10px;
         margin-right: 10px;
         margin-left: 10px;
         border: 1px solid red;
              }
       div {
              color: blue;
              text-align:center;
              font-size:40px;
             }
   </style>
   </head>
<body>
     <div>
            <p>Hitachi 冷氣控制<br></p>
            <form>
              <input type="submit"  formaction="/1" value="開冷氣">
              <input type="submit"  formaction="/0" value="關冷氣">
              <input type="submit"  formaction="/tup" value="升溫">
              <input type="submit"  formaction="/tdn" value="降溫">
            </form>
     </div>
</body>
</html>
)=====";
String sFinishedhead = R"=====(
<!DOCTYPE html>
<html>
    <head>
      <meta charset="UTF-8" />
      <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
      <title>設定ROUTER連線</title>
      <style>
      body {text-align: center;}
      input[type=submit] {background-color: #50FF50;font-size: 24px;}
      input[type=text]{font-size: 24px;max-width: 200px;}
      p {font-size: 22px;}
 </style>
    </head>
<body >

)=====";

String sFinishedend = R"=====(
<p>
請確認SSID與PASS是否正確
</p>
<p>
若不正確，請REST ESP再重新操作
</p>
<p>
若正確，請REST ESP即可自動連網
</p>
</body>
</html>
)=====";
