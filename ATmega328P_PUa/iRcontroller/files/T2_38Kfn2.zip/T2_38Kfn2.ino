int T=560; //us
int T16=16*T;//9000
int T7p5=7.5*T;//4500
int T3=3*T;//1690
int i;

struct stByte
 {
   unsigned char AddressL; //Lower Address
    unsigned char AddressH; 
    unsigned char cmd;
   unsigned char cmdinv; //Higher Address
 } ;

typedef struct stByte BYTES;
BYTES iRcode;

union unLONGINT
 {
  unsigned long uL; //4 bytes
  BYTES b; //4 bytes
 };
 typedef union unLONGINT LONGUNION ;
LONGUNION iRcodeL;


void setup() {

 //38K, D11 should not be changed
DDRB |=_BV(3); //pinMode(11,OUTPUT);
TCCR2A &= (~_BV(COM2A1)) & (~_BV(WGM20));
TCCR2A |= _BV(COM2A0) | _BV(WGM21);
OCR2A=210;
TCCR2B &=~_BV(WGM22) & ~_BV(CS22) & ~_BV(CS21);
TCCR2B |= _BV(CS20);
TCNT2=0;

}

void loop() {

  writeData(0xFE,0x01,0x10);
  delay(5000);
writeData(0xFE,0x01,0x11);
  delay(5000);
}


void writeData(unsigned char aH,unsigned char aL,unsigned char keyC)
{
iRcode.AddressH=aH;
iRcode.AddressL=aL;
iRcode.cmd=keyC;
iRcode.cmdinv=~keyC;
iRcodeL.b=iRcode;
DDRB &=~_BV(3); //D11  input
delay(10);

//sending leader code
DDRB |=_BV(3);  //38k D11 output
delayMicroseconds(T16);
DDRB &=~_BV(3); // D11 input
delayMicroseconds(T7p5);


for(i=0;i<32;i++)
{
   DDRB |=_BV(3);//38k
   delayMicroseconds(T);
   DDRB &=~_BV(3); //low
   if(iRcodeL.uL & 0x00000001) //1
    {   
       delayMicroseconds(T3);
    }
   else
    {
       delayMicroseconds(T);
    }
   iRcodeL.uL=iRcodeL.uL>>1;
}
//stop bit
DDRB |=_BV(3);
delayMicroseconds(T);
DDRB &=~_BV(3); 
}
 
