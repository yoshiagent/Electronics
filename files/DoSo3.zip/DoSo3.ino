int Do=262;
int Re=294;
int Mi=330;
int Fa=349;
int So=392;
int La=440;
int Si=494; 

int bt=1000; //　每分鐘60拍　,　一拍1000ms
int bt2=bt*2;
int bt12=bt/2;
int bt14=bt/4;
int bt18=bt/8; 
int SPK=8; 
int repeat=2;
int sNo=8;
int scale[ ] = {Do, So/2,So/2, La/2, So/2,0, Si/2, Do};
int bts[ ] = {bt14, bt18, bt18,bt14,bt14,bt14,bt14,bt14}; 

void note(int pin,int DoReMi,int dur )
{
tone(pin, DoReMi,dur);
delay(dur*1.3);
}

void setup(){
pinMode(SPK,OUTPUT); 
for (int ik=0;ik<repeat;ik++){

  for (int ii = 0; ii < sNo; ii++) {
     note(SPK, scale[ii],bts[ii]);
   }
  noTone(SPK);
  delay(2000); 
}
}

void loop(){}
