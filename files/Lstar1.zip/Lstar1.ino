int Do=262;
int Re=294;
int Mi=330;
int Fa=349;
int So=392;
int La=440;
int Si=494; 

int bt=500; //　每分鐘120拍　,　一拍500ms
int bt2=bt*2;
int bt12=bt/2;
int bt14=bt/4;
int bt18=bt/8; 
int SPK=18; 
int repeat=2;
int sNo=42;
int scale[ ] = {Do,Do,So,So,La,La,So,Fa,Fa,Mi,Mi,Re,Re,Do,
                So,So,Fa,Fa,Mi,Mi,Re,So,So,Fa,Fa,Mi,Mi,Re,
                Do,Do,So,So,La,La,So,Fa,Fa,Mi,Mi,Re,Re,Do};
int bts[ ] = {bt,bt,bt,bt,bt,bt,bt2,bt,bt,bt,bt,bt,bt,bt2,
              bt,bt,bt,bt,bt,bt,bt2,bt,bt,bt,bt,bt,bt,bt2,
              bt,bt,bt,bt,bt,bt,bt2,bt,bt,bt,bt,bt,bt,bt2}; 

void note(int pin,int DoReMi,int dur )
{
tone(pin, DoReMi,dur);
delay(dur*1.3);
}

void setup(){
pinMode(SPK,OUTPUT); 
for (int ik=0;ik<repeat;ik++){

for (int ii = 0; ii < sNo; ii++) {
note(SPK, scale[ii],bts[ii]);
}
//noTone(SPK);
delay(2000); 
}
}

void loop(){}
