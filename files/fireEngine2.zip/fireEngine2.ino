int SPK=18;
int fL=700;
int fH=1500;
int fStep=10;
int dtL2H=1500/(1500-700)*fStep;
int dtH2L=3500/(1500-700)*fStep;
void note(int pin,int DoReMi,int duration )
{
 tone(pin, DoReMi,duration);
 delay(duration);
}
void setup() {
pinMode(SPK,OUTPUT);
}

void loop() {
for (int f=700;f<=1500;f=f+fStep){
  note(SPK,f,dtL2H);
}
for (int f=1500;f>=700;f=f-fStep){
   note(SPK,f,dtH2L);
}
}
