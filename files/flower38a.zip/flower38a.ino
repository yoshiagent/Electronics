int Do=262;
int Re=294;
int Mi=330;
int Fa=349;
int So=392;
int La=440;
int Si=494; 
int bt=500; //　每分鐘120拍　,　一拍500ms
int bt2=bt*2;
int bt4=bt*4;
int bt12=bt/2;
int bt14=bt/4;
int bt18=bt/8;

int repeat=1; 
int SPK=8;
int scale[] = {So,So,Mi*2,Re*2,Do*2,Mi,Re,Mi,So,Mi*2,Re*2,Do*2,La,So,Mi,So};
int bts[] = {(bt*1.5), bt12, bt, bt12,bt12,bt,bt12,bt12,bt2,(bt*1.5),bt12,bt,bt14,bt14,bt12,bt4};
int sNo=16;

void note(int pin,int DoReMi,int dur )
{
tone(pin, DoReMi,dur);
delay(dur*1.3);
}

void setup(){
pinMode(SPK,OUTPUT);

for(int i=0;i<repeat;i++)
{
for (int ii = 0; ii < sNo; ii++) {
note(SPK, scale[ii],bts[ii]);
}
delay(1000);
}
}
void loop()
{

}


