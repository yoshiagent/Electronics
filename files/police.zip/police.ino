int SPK=8;
int freq;
void setup() {
pinMode(SPK,OUTPUT);
}

void loop() {
freq=700;
while(freq<=1500){
  tone(SPK,freq,3);
  delay(3);
  freq=freq+10;
}
while(freq>=700){
  tone(SPK,freq,1);
  delay(1);
  freq=freq-10;
}

}
